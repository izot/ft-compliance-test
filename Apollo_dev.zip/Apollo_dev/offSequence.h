/* offSequence.h - Neuron-C Network Variable Type header file */

#ifndef _offSequence_h_enumeration
#define _offSequence_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "offSequence" enum set, index 10 */

typedef enum offSequence {
 	/*   0 */ 	OFF_BY_POWER = 0, 	/* Switch power without commanding OLC */
 	/*   1 */ 	OFF_BY_CMD = 1, 	/* Allow for command before switch power */
 	/*   2 */ 	OFF_WITH_DEFAULT = 2, 	/* Send a default level before switching power */
 	/*  -1 */ 	MEM_NUL = -1
} offSequence;

/* end of: offSequence */
#endif
