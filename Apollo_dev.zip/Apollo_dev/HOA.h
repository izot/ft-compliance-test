/* HOA.h - Neuron-C Network Variable Type header file */

#ifndef _HOA_h_enumeration
#define _HOA_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "HOA" enum set, index 11 */

typedef enum HOA {
 	/*   0 */ 	AUTO = 0, 	/* Auto */
 	/*   1 */ 	HAND = 1, 	/* ON */
 	/*   2 */ 	OFF = 2, 	/* OFF */
 	/*  -1 */ 	MEM_NUL = -1
} HOA;

/* end of: HOA */
#endif
