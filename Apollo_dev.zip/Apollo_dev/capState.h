/* capState.h - Neuron-C Network Variable Type header file */

#ifndef _capState_h_enumeration
#define _capState_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "capState" enum set, index 9 */

typedef enum capState {
 	/*   0 */ 	DISABLED = 0,
 	/*   1 */ 	ENABLED_LOCKOUT = 1,
 	/*   2 */ 	ENABLED = 2,
 	/*   3 */ 	PRE_ALARM = 3,
 	/*   4 */ 	ALARM_ACTIVE = 4,
 	/*   5 */ 	INPUTS_INVALID = 5,
 	/*  -1 */ 	MEM_NUL = -1
} capState;

/* end of: capState */
#endif
