/* eRestart.h - Neuron-C Network Variable Type header file */

#ifndef _eRestart_h_enumeration
#define _eRestart_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "eRestart" enum set, index 6 */

typedef enum eRestart {
 	/*   0 */ 	REBOOT = 0,
 	/*   1 */ 	STACK_ONLY = 1,
 	/*  -1 */ 	MEM_NUL = -1
} eRestart;

/* end of: eRestart */
#endif
