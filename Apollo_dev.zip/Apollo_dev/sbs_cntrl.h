/* sbs_cntrl.h - Neuron-C Network Variable Type header file */

#ifndef _sbs_cntrl_h_enumeration
#define _sbs_cntrl_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "sbs_cntrl" enum set, index 8 */

typedef enum sbs_cntrl {
 	/*   0 */ 	STARTUP = 0,
 	/*   1 */ 	DISABLE = 1,
 	/*   2 */ 	ACTIVE = 2,
 	/*   3 */ 	REBUILD = 3,
 	/*   4 */ 	BUILD_ACTIVE = 4,
 	/*   5 */ 	SBS_DOWN = 5,
 	/*  -1 */ 	MEM_NUL = -1
} sbs_cntrl;

/* end of: sbs_cntrl */
#endif
