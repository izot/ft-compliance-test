/* LS_state.h - Neuron-C Network Variable Type header file */

#ifndef _LS_state_h_enumeration
#define _LS_state_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "LS_state" enum set, index 7 */

typedef enum LS_state {
 	/*   0 */ 	LS_UNUSED = 0, 	/* Unused */
 	/*   1 */ 	LS_UNKNOWN = 1, 	/* Unknown */
 	/*   2 */ 	LS_NORMAL = 2, 	/* Normal */
 	/*   3 */ 	LS_LEAK_DETECTED = 3, 	/* Leak Detected */
 	/*  -1 */ 	MEM_NUL = -1
} LS_state;

/* end of: LS_state */
#endif
