FMTGEN - Copyright (c) 1991-2002 Echelon Corporation
Input file: C:\Program Files (x86)\LonWorks\Types\ApolloDev\ApolloDev.fmt
Compilation complete.
