/* LStatus.h - Neuron-C Network Variable Type header file */

#ifndef _LStatus_h_enumeration
#define _LStatus_h_enumeration

/* The enum definition below defines the enumeration to be used */
/* with tagname "LStatus" enum set, index 1 */

typedef enum LStatus {
 	/*   0 */ 	LC_NORMAL = 0,
 	/*   1 */ 	LC_FAULT = 1,
 	/*   2 */ 	LC_TIMEOUT = 2,
 	/*   3 */ 	LC_STARTUP = 3,
 	/*  -1 */ 	MEM_NUL = -1
} LStatus;

/* end of: LStatus */
#endif
